cd test
./Apriori_res/MiningUsingApriori
cat result.txt
