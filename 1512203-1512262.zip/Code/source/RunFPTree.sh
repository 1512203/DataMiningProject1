./FPTree_res/MiningUsingFPTree
cat result.txt
